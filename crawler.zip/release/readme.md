# Project Workflow and Data Structure README

## Overview
This README outlines the workflow involving five Python scripts and the structure of their output JSON files. The scripts are part of a data extraction and merging process, each playing a unique role in scraping and organizing data from web sources.

## Workflow
The scripts must be run sequentially as each script's output is utilized by the subsequent one. The order and functionality of each script are as follows:

1. **get_degree.py**: 
   - Scrapes degree names and links.
   - Outputs `degrees.json`.

2. **get_program.py**: 
   - Scrapes program names and links.
   - Outputs `programs.json`.

3. **get_plan.py**: 
   - Extracts the main content from the program links, detailing program descriptions.
   - Outputs `program_details.json`.

4. **get_course.py**: 
   - Scrapes courses mentioned in the program link content, including course codes, names, and descriptions.
   - Stores each unique (program_name, course_code) pair as a separate record.
   - Outputs `courses.json`.

5. **merge.py**: 
   - Merges `courses.json` with `program_details.json` based on `program_name`.
   - Courses corresponding to the same program are aggregated into a single field.
   - Outputs `program_courses.json`.

## JSON Files Structure
There are five JSON files generated throughout this workflow, each with its specific structure:

1. **degrees.json**:
   - Fields: `degree_name`, `degree_link`.

2. **programs.json**:
   - Fields: `degree_name`, `program_name`, `program_link`.

3. **program_details.json**:
   - Fields: `degree_name`, `program_name`, `program_link`, `main_content`.

4. **courses.json**:
   - Fields: `degree_name`, `program_name`, `course_code`, `course_name`, `course_link`, `course_details`.

5. **program_courses.json** (contains the most comprehensive data):
   - Fields: `degree_name`, `program_name`, `program_link`, `main_content`, `courses`.
   - `courses`: A dictionary structured with `course_code` as the key, and each entry contains `course_code`, `course_name`, `course_link`, `course_details`.

## Note
`program_courses.json` encompasses all the fields from the other files, making it the most comprehensive data source among them.
