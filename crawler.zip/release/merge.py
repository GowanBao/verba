import json
from collections import defaultdict

# read and summarize courses.json
def read_and_summarize_json(file_path):
    program_courses = defaultdict(dict)

    with open(file_path, 'r') as file:
        for line in file:
            try:
                obj = json.loads(line)
                program_name = obj["program_name"]
                course_code = obj["course_code"]
                course_info = {
                    "course_code": obj["course_code"],
                    "course_name": obj["course_name"],
                    "course_link": obj["course_link"],
                    "course_details": obj["course_details"]
                }
                program_courses[program_name][course_code] = course_info
            except json.JSONDecodeError:
                pass  # ignore lines with JSONDecodeError

    return program_courses

# read program_details.json
def read_program_details(file_path):
    program_details = []

    with open(file_path, 'r') as file:
        for line in file:
            try:
                program_detail = json.loads(line)
                program_details.append(program_detail)
            except json.JSONDecodeError:
                pass  # ignore lines with JSONDecodeError

    return program_details

# add courses to program_details
def add_courses_to_program_details(program_details, summarized_data):
    for program in program_details:
        program_name = program["program_name"]
        program["courses"] = summarized_data.get(program_name, {})
    return program_details

# save to JSON
def save_to_json(data, file_path):
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4, ensure_ascii=False)

# main function
courses_file_path = 'data/courses.json'  
summarized_data = read_and_summarize_json(courses_file_path)  

program_details_file_path = 'data/program_details.json'  
program_details = read_program_details(program_details_file_path)  

# add courses to program_details
updated_program_details = add_courses_to_program_details(program_details, summarized_data)

# save to JSON
final_json_file_path = 'data/program_courses.json'  # final JSON file path
save_to_json(updated_program_details, final_json_file_path)

print(updated_program_details[0])  # print one program for testing