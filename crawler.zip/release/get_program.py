import json
import requests
from bs4 import BeautifulSoup
from loguru import logger
from tqdm import tqdm

degrees = []
with open('data/degrees.json', 'r') as f:
    for line in f:
        degrees.append(json.loads(line))

all_programs = []

success = 0
failed = 0

for degree in tqdm(degrees):

    try:
        degree_name = degree["degree_name"]
        logger.info(f"Degree Name: {degree_name}")

        # URL of the page
        url = degree["degree_link"] + "#programstext"
        logger.info(f"URL: {url}")

        success += 1

        # Send a GET request to the URL
        response = requests.get(url)

        link_prefix = "https://www.queensu.ca"

        if response.status_code == 200:
            # Parse the content of the page using BeautifulSoup
            soup = BeautifulSoup(response.text, 'html.parser')

            program_types = soup.find_all('h3')  # Find all headers to use as category names
            program_lists = soup.find_all('div', class_='sitemap')  # Find all program lists

            for category, programs in zip(program_types, program_lists):
                category_name = category.text.strip()  # Get category name
                program_links = programs.find_all('a')  # Get all programs under this category

                for program in program_links:
                    program_name = program.text.strip()
                    program_link = link_prefix + program['href']

                    logger.info(f"Program Name: {program_name}")
                    logger.info(f"Program Link: {program_link}")

                    all_programs.append({
                        "degree_name": degree_name,
                        # "category_name": category_name,
                        "program_name": program_name,
                        "program_link": program_link
                    })

        else:
            logger.error(f"Error: {response.status_code}")

    except:
        
        failed += 1

        logger.error(f"Error: Failed to get program {degree_name} from {url}")

logger.info(f"Success: {success}, Failed: {failed}")

logger.info(f"Number of programs: {len(all_programs)}")

# save to json

with open('data/programs.json', 'w') as outfile:
    for program in all_programs:
        json.dump(program, outfile)
        outfile.write('\n')
