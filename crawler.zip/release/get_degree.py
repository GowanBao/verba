import json
import requests
from bs4 import BeautifulSoup
from loguru import logger

# URL of the page
url = "https://www.queensu.ca/academic-calendar/arts-science/schools-departments-programs/"

# Send a GET request to the URL
response = requests.get(url)

all_degrees = []
link_prefix = "https://www.queensu.ca"

# Check if the request was successful
if response.status_code == 200:
    # Parse the content of the page using BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')

    # Find the specific div containing the degrees
    sitemap_div = soup.find('div', class_='sitemap')

    # If the sitemap div is found, proceed to find all 'a' tags within 'li' tags
    if sitemap_div:
        degrees = sitemap_div.find_all('li')

        # Extract and print the program name and href for each program
        for degree in degrees:
            name = degree.find('a').get_text().strip()
            href = degree.find('a')['href']

            logger.info(f"Program Name: {name}, Link: {link_prefix + href}")

            # Append the program name and href to the all_degrees list
            all_degrees.append({
                "degree_name": name,
                "degree_link": link_prefix + href
            })

else:
    logger.error("Error retrieving the page")

# total number of degrees
logger.info(f"Total number of degrees: {len(all_degrees)}")

# save to json

with open('data/degrees.json', 'w') as outfile:
    for degree in all_degrees:
        json.dump(degree, outfile)
        outfile.write('\n')
