import json
import requests
from bs4 import BeautifulSoup
from loguru import logger
from tqdm import tqdm

# read programs.json
with open('data/programs.json', 'r') as f:
    programs = [json.loads(line) for line in f]

all_program_details = []

# iterate through each program
for program in tqdm(programs):
    program_name = program["program_name"]
    program_link = program["program_link"]
    degree_name = program["degree_name"]  # add degree name

    logger.info(f"Degree Name: {degree_name}")
    logger.info(f"Program Name: {program_name}")
    logger.info(f"Program Link: {program_link}")

    # request program link
    response = requests.get(program_link)

    if response.status_code == 200:
        # parse response
        soup = BeautifulSoup(response.text, 'html.parser')
        main_content = soup.find('div', id='textcontainer')
        if main_content:
            text = main_content.get_text('|', strip=True)
            
            # add program name and link and degree name to the dictionary
            all_program_details.append({
                "degree_name": degree_name,
                "program_name": program_name,
                "program_link": program_link,
                "main_content": text
            })
        else:
            logger.error("No main content found")
    else:
        logger.error(f"error, status_code：{response.status_code}")

# save all program details to json file
with open('data/program_details.json', 'w') as outfile:
    for program_detail in all_program_details:
        json.dump(program_detail, outfile)
        outfile.write('\n')
