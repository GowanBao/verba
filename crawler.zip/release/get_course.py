import json
import requests
from bs4 import BeautifulSoup
from loguru import logger
from tqdm import tqdm

link_prefix = "https://www.queensu.ca"

# read programs.json
with open('data/programs.json', 'r') as f:
    programs = [json.loads(line) for line in f]

all_course_details = []
max_retries = 3  # set max retries for requests

# add counters for success and failure
programs_success_count = 0
programs_failed_count = 0
courses_success_count = 0
courses_failed_count = 0

def get_response(url):
    for attempt in range(max_retries):
        try:
            response = requests.get(url, timeout=10)  # add timeout for requests
            if response.status_code == 200:
                return response
        except requests.ConnectionError:
            logger.warning(f"Connection error occurred while accessing {url}, retrying ({attempt+1}/{max_retries})")
        except requests.exceptions.Timeout:
            logger.warning(f"Timeout error occurred while accessing {url}, retrying ({attempt+1}/{max_retries})")
        

    logger.error(f"Failed to access {url} after {max_retries} attempts")
    return None

for program in tqdm(programs):

    program_name = program["program_name"]
    program_link = program["program_link"]
    degree_name = program["degree_name"]

    logger.info(f"Program Name: {program_name}")
    logger.info(f"Program Link: {program_link}")

    response = get_response(program_link)
    if response:
        programs_success_count += 1
        soup = BeautifulSoup(response.text, 'html.parser')
        main_content = soup.find('div', id='textcontainer')
        if main_content:
            for a_tag in main_content.find_all('a', href=True):
                if a_tag['href'].startswith('/academic-calendar/search/?P='):
                    course_link = link_prefix + a_tag['href']
                    response = get_response(course_link)
                    if response:
                        courses_success_count += 1
                        soup = BeautifulSoup(response.text, 'html.parser')
                        course_div = soup.find('div', class_='searchresult search-courseresult')

                        if course_div is None:
                            logger.warning(f"No course information found for {course_link}")
                            courses_failed_count += 1  # add counter for failed courses
                            continue  # skip this course

                        first_string = course_div.h2.get_text().strip()
                        course_details = course_div.find('div', class_='courseblock').get_text('|',strip=True).strip()

                        split_list = first_string.split()
                        if len(split_list) > 2:
                            course_code = " ".join(split_list[:2])
                            course_name = " ".join(split_list[2:])
                        else:
                            course_code = first_string
                            course_name = ""

                        all_course_details.append({
                            "degree_name": degree_name,
                            "program_name": program_name,
                            "course_code": course_code,
                            "course_name": course_name,
                            "course_link": course_link,
                            "course_details": course_details
                        })
                    else:
                        courses_failed_count += 1
    else:
        programs_failed_count += 1

# save all_course_details to courses.json
with open('data/courses.json', 'w') as outfile:
    for course in all_course_details:
        json.dump(course, outfile)
        outfile.write('\n')

# log the number of programs and courses crawled
logger.info(f"Programs successfully crawled: {programs_success_count}")
logger.info(f"Programs failed to crawl: {programs_failed_count}")
logger.info(f"Courses successfully crawled: {courses_success_count}")
logger.info(f"Courses failed to crawl: {courses_failed_count}")
