# Verba Guide

## Installation

```bash
pip install goldenverba
```

## Configuration

Please replace the OpenAi api key in the `.env` file with your own key.

## Launch

Please firstly navigate to the directory where you have your `.env` and `verba_config.json` file, and then run the following command:

```bash
verba start
```

And then you visit the following link in your browser: `localhost:8000`.

## Usage

There is an `Add Document` button on the top right corner of the page, you can click it to upload the documents (in `.txt` or `.pdf` format).

As for the Generator, you can choose from GPT3Generator and GPT4Generator and compare the results.

As for the Chunker, you can choose from TokenChunker, WordChunker and SentenceChunker and compare the results.