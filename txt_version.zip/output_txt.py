import json
import os
import shutil

def save_programs_to_txt(file_path):
    # define output directory
    output_dir = './txt_data'
    
    # delete and recreate the directory if it exists
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
    os.makedirs(output_dir, exist_ok=True)
    
    # open file with UTF-8 encoding
    with open(file_path, 'r', encoding='utf-8') as file:
        programs = json.load(file)
        
        for program in programs:
            # combine degree name and program name for the file name, removing disallowed characters
            degree_name = program.get('degree_name', 'UnknownDegree')  # Default to 'UnknownDegree' if not found
            combined_name = f"{degree_name}_{program['program_name']}".replace('/', '_').replace('\\', '_').replace(':', '_')
            file_path = os.path.join(output_dir, f"{combined_name}.txt")
            
            with open(file_path, 'w', encoding='utf-8') as outfile:
                # write program name and program details
                outfile.write(f"Program Name: {program['program_name']}\n\n")
                outfile.write(f"Program Details: {program['main_content']}\n\n")
                
                # write course information
                outfile.write("Courses:\n")
                for course_code, course_info in program['courses'].items():
                    outfile.write(f"{course_code}: {course_info['course_name']}\n")

# assume JSON file path has been defined as file_path
file_path = 'data/program_courses.json'

# call the function to start processing
save_programs_to_txt(file_path)

print("Programs have been saved to text files in 'txt_data' folder.")
